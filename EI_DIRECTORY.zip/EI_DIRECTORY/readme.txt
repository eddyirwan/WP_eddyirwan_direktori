Put this folder EI_DIRECTORY into /wp-content/uploads/

if u run by linux, chmod this folder <EI_DIRECTORY> to 777 or the same attribute with uploads folder

Eddy Irwan